export const parameters={};
export function polar(region,alpha,camber){throw Error('Implement the section model');}
export function forces(state,controls,environment,poseOverride){throw Error('Implement forces');}
export function accelerations(state,controls,environment){throw Error('Implement coupled dynamics');}
export function step(state,controls,environment,dt){throw Error('Implement integration');}
